namespace Week_5_Tutorial_Workshop
{
    // Abstract class representing a generic vehicle
    public abstract class Vehicle_1
    {
        // Starts the vehicle's engine 
        public abstract void StartEngine();

        // Stops the vehicle's engine
        public abstract void StopEngine();

        // Displays a generic message about the vehicle
        public void Display()
        {
            Console.WriteLine("This is a vehicle");
        }
    }
}