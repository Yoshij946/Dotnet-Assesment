namespace Week_5_Tutorial_Workshop
{
    public class Bike_1 : Vehicle_1
    {
        // Starts the bike's engine
        public override void StartEngine()
        {
            Console.WriteLine("Bike engine started");
        }

        // Stops the bike's engine
        public override void StopEngine()
        {
            Console.WriteLine("Bike engine stopped");
        }
    }
}