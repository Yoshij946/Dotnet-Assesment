namespace Week_5_Tutorial_Workshop
{
    // Represents a generic vehicle
    public class Vehicle
    {
        // Vehicle brand
        public string Brand { get; set; }

        // Vehicle speed in km/h
        public int Speed { get; set; }

        // Constructor to initialize brand and speed
        public Vehicle(string brand, int speed)
        {
            Brand = brand;
            Speed = speed;
        }

        // Starts the vehicle
        public void Start()
        {
            Console.WriteLine($"{Brand} is starting...");
        }

        // Stops the vehicle
        public void Stop()
        {
            Console.WriteLine($"{Brand} is stopping...");
        }

        // Displays vehicle information (can be overridden)
        public virtual void DisplayInfo()
        {
            Console.WriteLine($"Brand: {Brand}");
            Console.WriteLine($"Speed: {Speed} km/h");
        }
    }
}