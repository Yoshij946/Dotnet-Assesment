namespace Week_5_Tutorial_Workshop
{
    // Represents a car, derived from the Vehicle base class
    public class Car : Vehicle
    {
        // Number of seats in the car
        public int Seats { get; set; }

        // Constructor to initialize brand, speed, and seats
        public Car(string brand, int speed, int seats)
            : base(brand, speed)
        {
            Seats = seats;
        }

        // Displays car information including brand, speed, and seats
        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Seats: {Seats}");
        }
    }
}