﻿namespace Week_5_Tutorial_Workshop;

class Program
{
    static void Main(string[] args)
    {   
        // Task 1
        
        // Create bank account object
        BankAccount account = new BankAccount("ACC1001", 5000);
        
        // Display account number
        Console.WriteLine("Account Number: " + account.AccountNumber);
        
        // Deposit money
        account.Deposit(2000);
        
        // Withdraw money
        account.Withdraw(1500);
        
        // Display remaining balance
        Console.WriteLine("Remaining Balance: " + account.Balance);
        
        
        
        
        
        
        
        
        // Task 2
        
        // Create objects
        Car car = new Car("Toyota", 180, 5);
        Motorcycle bike = new Motorcycle("Yamaha", 220, 600);
        
        // Demonstrate Car
        Console.WriteLine("=== CAR DETAILS ===");
        car.Start();
        car.DisplayInfo();
        car.Stop();
        
        Console.WriteLine();
        
        // Demonstrate Motorcycle
        Console.WriteLine("=== MOTORCYCLE DETAILS ===");
        bike.Start();
        bike.DisplayInfo();
        bike.Stop();
        
        
        
        
        
        // Task 3
        
        Printer printer = new Printer();
        
        // Call overloaded methods
        printer.Print("Hello C#");
        printer.Print(100);
        printer.Print("Printing multiple times", 5);
        
        
        
        
        
        
        // Task 3.1
        // Create a generic Teacher instance and call methods
        Teacher englishTeacher = new Teacher("Pream Tamang");
        englishTeacher.Teaching();        // Calls the base Teaching method
        Teacher.SalaryInfo();             // Calls static method (cannot be overridden)

        Console.WriteLine();

        // Create a NepaliTeacher instance and call methods
        NepaliTeacher nepaliTeacher = new NepaliTeacher("Home Sir");
        nepaliTeacher.Teaching();         // Calls overridden Teaching method
        Teacher.SalaryInfo();             // Static method from base class

        Console.WriteLine();

        // Create an EnglishTeacher instance and call methods
        EnglishTeacher englishTeacher2 = new EnglishTeacher("Rajesh Karki");
        englishTeacher2.Teaching();       // Calls base Teaching method (not overridden)
        Teacher.SalaryInfo();             // Static method from base class
        
        
        
        
        
        
        
        
        // Task 4
        
        // Create objects of Car and Bike using Vehicle_1 reference
        Vehicle_1 myCar = new Car_1();
        Vehicle_1 myBike = new Bike_1();

        // Call methods on the Car object
        myCar.Display();        // Calls concrete method from Vehicle_1
        myCar.StartEngine();    // Calls overridden StartEngine method in Car_1
        myCar.StopEngine();     // Calls overridden StopEngine method in Car_1

        Console.WriteLine();    // Separate output for clarity

        // Call methods on the Bike object
        myBike.Display();       // Calls concrete method from Vehicle_1
        myBike.StartEngine();   // Calls overridden StartEngine method in Bike_1
        myBike.StopEngine();    // Calls overridden StopEngine method in Bike_1

        
        
        
        
        
        
        
        
        
        // Task 5
        // Create an instance of ElectronicsStore
        ElectronicsStore store = new ElectronicsStore();

        // Create Laptop and Smartphone objects
        Laptop myLaptop = new Laptop("Dell", 1499.50);
        Smartphone myPhone = new Smartphone("Apple", 999.99);

        // Add devices to the store
        store.AddDevice(myLaptop);
        store.AddDevice(myPhone);

        // Display details of all devices in the store
        // Includes calling child-specific methods like TurnOnBattery and EnableCamera
        store.ShowAllDeviceDetails();

    }
}