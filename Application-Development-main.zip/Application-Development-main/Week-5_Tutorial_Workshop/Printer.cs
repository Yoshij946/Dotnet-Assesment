namespace Week_5_Tutorial_Workshop
{
    // Demonstrates method overloading for printing messages and numbers
    public class Printer
    {
        // Prints a string message
        public void Print(string message)
        {
            Console.WriteLine("Message: " + message);
        }

        // Prints an integer number
        public void Print(int number)
        {
            Console.WriteLine("Number: " + number);
        }

        // Prints a string message along with a count
        public void Print(string message, int count)
        {
            Console.WriteLine($"Message: {message}, Count: {count}");
        }
    }
}