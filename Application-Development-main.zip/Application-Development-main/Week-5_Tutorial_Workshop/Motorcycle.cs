namespace Week_5_Tutorial_Workshop
{
    // Represents a motorcycle, derived from the Vehicle base class
    public class Motorcycle : Vehicle
    {
        // Engine capacity in cubic centimeters
        public int EngineCC { get; set; }

        // Constructor to initialize brand, speed, and engine capacity
        public Motorcycle(string brand, int speed, int engineCc)
            : base(brand, speed)
        {
            EngineCC = engineCc;
        }

        // Displays motorcycle details including brand, speed, and engine capacity
        public override void DisplayInfo()
        {
            base.DisplayInfo();
            Console.WriteLine($"Engine Capacity: {EngineCC} cc");
        }
    }
}