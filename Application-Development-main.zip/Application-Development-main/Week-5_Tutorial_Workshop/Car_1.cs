namespace Week_5_Tutorial_Workshop
{
    public class Car_1 : Vehicle_1
    {
        // Starts the car's engine
        public override void StartEngine()
        {
            Console.WriteLine("Car engine started");
        }

        // Stops the car's engine
        public override void StopEngine()
        {
            Console.WriteLine("Car engine stopped");
        }
    }
}