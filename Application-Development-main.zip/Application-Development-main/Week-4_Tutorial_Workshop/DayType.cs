namespace Week_4_Tutorial_Workshop;

public enum DayType
{
    Weekday,
    Weekend
}