namespace Week_4_Tutorial_Workshop;

public class Student
{
    // Instance fields
    public string Name;
    public int Age;
    public string Address;

    // Static field
    public static string SchoolName = "Mount Hermon Children Academy";
}