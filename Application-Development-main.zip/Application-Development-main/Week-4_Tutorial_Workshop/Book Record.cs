namespace Week_4_Tutorial_Workshop;

public record Book(string title, string author, double price);