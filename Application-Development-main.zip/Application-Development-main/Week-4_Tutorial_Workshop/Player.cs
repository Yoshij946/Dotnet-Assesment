namespace Week_4_Tutorial_Workshop;

public class Player
{
    public string playerName;
    public int level;
    public int health;

    // Default Constructor
    public Player()
    {
        Console.WriteLine("Default constructor has been called");
    }

    // Parameterized Constructor
    public Player(string name, int lvl, int hp)
    {
        playerName = name;
        level = lvl;
        health = hp;
    }
}