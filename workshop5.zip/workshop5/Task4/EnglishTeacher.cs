namespace Task4
{
    // Represents an English teacher derived from the Teacher base class
    public class EnglishTeacher : Teacher
    {
        // Constructor to initialize the teacher's name
        public EnglishTeacher(string name) : base(name) { }
    }
}