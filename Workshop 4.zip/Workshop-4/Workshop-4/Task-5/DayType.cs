public enum DayType
{
    Weekday,
    Weekend
}
