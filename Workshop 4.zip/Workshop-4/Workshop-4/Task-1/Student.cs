public class Student
{
    // 3 instance fields
    public string name;
    public int age;
    public string address;

    // 1 static field
    public static string schoolName = "Itahari International College";
}
